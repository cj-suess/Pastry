package csx55.pastry.node;

public class Data {
    
}
